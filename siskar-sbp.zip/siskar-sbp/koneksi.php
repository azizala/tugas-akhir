<?php  
//membuat koneksi ke database  

	$host 		= 'localhost:3307';  
  	$user 		= 'root';        
  	$password 	= '';        
  	$database 	= 'sbp';    
      
  $konek_db = mysqli_connect($host, $user, $password, $database);
        
?>